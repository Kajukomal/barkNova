const express = require('express');
const app = express();
const path = require('path');
//const bodyParser = require('body-parser');
require("./db/conn");
const User = require("./models/user")
const UserM = require("./models/usermessage");

const hbs = require('hbs');
const port = process.env.PORT || 8000;

const StaticPath = path.join(__dirname,'../public');
const viewsspath = path.join(__dirname,'../templates/views');
const partialspath = path.join(__dirname,'../templates/partials');


 app.use(express.static(StaticPath))

app.use('/css', express.static(path.join(__dirname,'../node_modules/bootstrap/dist/css')))
app.use('/js', express.static(path.join(__dirname,'../node_modules/bootstrap/dist/js')))
app.use('/jq', express.static(path.join(__dirname,'../node_modules/jquery/dist')))

app.use(express.urlencoded({extended:false}))
app.set('view engine','hbs');
app.set('views',viewsspath);
hbs.registerPartials(partialspath)


app.post("/signup", async(req,res) => {
    console.log(req.body)
    const u1 = new User(req.body)
    console.log(u1)
    try {
        await u1.save()
        res.status(201).render("index")
    } catch (error) {
        res.status(400).send(error)
    }
    
})

app.post('/login',async(req,res) => {
    try {
        const user = await User.findOne({email: req.body.email,password: req.body.password})
        res.status(201).render("dash")
    } catch (error) {
        res.status(400).send(error)
    }
})

app.post("/contact", async(req,res) => {
    try{
        const userData = new UserM (req.body);
        console.log(userData)
        await userData.save();
        res.status(201).render("index")
    } catch (error){
        res.status(500).send(error);
    }
    
})

app.get("/logout",(req,res) => {
    res.render("index")
})

app.get("/",(req,res) => {
    res.render("index")
})

app.listen(port, () => {
    console.log('server is listening to the port', port);
})